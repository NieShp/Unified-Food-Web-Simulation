% this code is used to generate Fig.2A & Fig.S1

clear;
RE=[];
sim = 1;

% species have same max and min N:C ratios
par.Q_max=[0.2; 0.2; 0.2];
par.Q_min=[0.05; 0.05; 0.05];

LAMBDA = [0 0.05 0.25 0.45];
for la = 1:4
    for S = 0.1 : 0.01: 1
        warningState = warning('off', 'all');
        % Plant and animal initial richness
        par.S_b = 1;   % initial plant richenss
        par.S_c = 2;   % initial animal richness
        % generate species body mass and food web topology based on body mass
        par.L = [0 0 0; 1 0 0; 0 1 0];
        par.mass =[1; 100; 10000];
        
        % several parameter about mineral pool
        par.mu = 0.25;               % mineral nutrient supply rate
        par.nu = 0.1095;             % mineral nutrient lose rate
        par.nu_detritus = 0.3066;    % organic detritus nutrient lose rate
        
        % fraction of metabolic nutrient is egested organic detritus pool (indierct nutrient cycling)
        par.rho  = 0.25;
        
        % parameter in stoichiometrically dominated metabolism
        par.lambda = LAMBDA(la);
        
        % species metabolism rate and decomposer lose rate
        par.m=zeros(par.S_b+par.S_c,1);
        par.m(1:par.S_b,1)=0.02;
        par.m(1+par.S_b:par.S_b+par.S_c,1)=0.005;
        
        % organic and mineral parameter
        par.mu = 0.25;        % mineral nuttient supply rate
        par.S  = S;           % nutrient supply concentration
        
        % N:C ratio of decomposer
        par.NC_ratio_decomposer = 0.125;
        
        % plant maximum growth rate
        par.r_max = 0.15;
        
        % decomposer growth rate and dead rate from Cherif & Loreau 2013
        par.l = 0.3;
        par.x_M = 0.15;
        
        % plant nutrient taking up from mineral nutrient
        par.V =  0.15;
        par.K =  1;
        
        % Holling type
        par.q = 2;
        
        % feeding relationships (Rall et al. 2012; Schneider et al. 2016)
        % bij (attack rate), hij (handling time), c (predation interference) and assimilation
        % attack rate
        par.a = zeros(par.S_c+par.S_b);
        b0 = 0.45 ;
        beta_Cons=normrnd(0.47, 0.00,[par.S_b+par.S_c, 1]);
        beta_Prey=normrnd(0.15, 0.00,[par.S_b+par.S_c, 1]);
        par.a=b0*par.mass.^beta_Cons.*(par.mass.^beta_Prey)';
        % par.a(:,1:par.S_b)=b0*par.mass.^beta_Cons.*ones(1,par.S_b)*1;   % plant cannot move
        % handing time
        h0 = 0.0001;
        h_Cons=normrnd(-0.48, 0.00, [par.S_b+par.S_c, 1]);
        h_Prey=normrnd( 0.34, 0.00, [par.S_b+par.S_c, 1]);
        par.h=h0*par.mass.^h_Cons.*(par.mass.^h_Prey)';
        % predation interference
        par.c = 0.0185 * ones(par.S_b+par.S_c, 1);
        
        % maximal assimilation rate
        par.e_max=0.85 * ones(par.S_b+par.S_c,par.S_b+par.S_c);
        
        % initial value of ODEs in food webs dynamics
        B0_carbon = 0 * rand(par.S_b+par.S_c,1) +  0.1;         % initial carbon stock
        B0_nutrient = B0_carbon.*(par.Q_max+par.Q_min)/2;     % initial nutrient stock
        BO_decomposer = 0.1*[1; par.NC_ratio_decomposer];         % initial decomposer community
        B0_detritus = 0.1*[1; par.NC_ratio_decomposer];           % initial detritus
        B0_mineral = 0.1;  % initial mineral nutrient
        B0 = [B0_carbon; B0_nutrient; BO_decomposer; B0_detritus; B0_mineral]; % initial value
        
        % options = odeset('RelTol', 1e-3, 'AbsTol', 1e-6, 'MaxStep', 1e-5);
        Time = 1e6;
        [t_B,y_B]=ode15s(@(t,B) foodweb_dynmaics(B,par),[0,Time], B0);
        
        % Ecosystem properties calculation
        Biomass = y_B(end,1:par.S_b+par.S_c)';
        Nutrient= y_B(end,1+par.S_b+par.S_c:2*(par.S_b+par.S_c))';
        Q=Nutrient./Biomass;
        
        
        RE(sim,1)=par.S;
        RE(sim,2)=Q(1);
        RE(sim,3)=Q(2);
        RE(sim,4)=Q(3);
        RE(sim,5)=par.lambda;
        sim = sim +1;
        
    end
end

% clf
% plot(RE(:,1),RE(:,2),'g-','LineWidth',2);hold on
% plot(RE(:,1),RE(:,3),'k-','LineWidth',2);hold on
% plot(RE(:,1),RE(:,4),'r-','LineWidth',2,'MarkerIndices',1:10:length(RE(:,4)));hold on
% plot(RE(:,1),(par.Q_max(2) + par.Q_min(2))/2 * ones(size(RE(:,4),1),1),'m--','LineWidth',2,'MarkerIndices',1:5:length(RE(:,4)))
% xlabel("Nutrient supply (S)")
% ylabel("Species nutrient: carbon ratio")
% legend(["Plant","Herbivore","Carnivore", "(Q_H^{max}+Q_H^{min})/2 & (Q_C^{max}+Q_C^{min})/2"])
% set (gca, 'FontSize', 18);
% xlim([0.1, 1])

[m,n]=size(RE);
data_cell = mat2cell(RE, ones(m,1), ones(n,1)); % 将data切割成m*n的cell矩阵
title = {'nutrient_supply','plant_NC','herbivore_NC','carnivore_NC','lambda'};
result = [title; data_cell];
s = xlswrite('simulated_data_simple_chain.xlsx', result);
