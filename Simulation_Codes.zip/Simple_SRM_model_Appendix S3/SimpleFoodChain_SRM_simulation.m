% This code is used to generate the data for ploting Fig.3A

clear
close all
par.a = 0.81;    % attack rate
par.h = 0.1;     % handlign time
par.r= 1.2;      % resource growth rate
par.m= 0.27;     % consumer mortality
par.Q0 = 0.0038; % resource minimal N:C ratio
par.e=0.8;       % consumer maximal assimialtion rate

i = 1;
q = 5*linspace(0.001, 0.01, 101);
NT = linspace(-2.75, -0.75, 101);

for x1 = 1 : length(q)
    for x2 = 1 : length(NT)
        if mod(i, 100) == 0  
            disp(i)  
        end    
        par.q = q(x1);           % consumer N:C ratio 
        par.N = 10.^NT(x2);      % total nutrient
        Time = 10000;
        B0=[0.01;0.01];
        options = odeset('RelTol', 1e-4, 'AbsTol', 1e-4, 'MaxStep', 1e-1);
        [t_B,y_B]=ode45(@(t,B) SimpleFoodChain_SRM(B,par),[0,Time], B0, options);
        indx = find(t_B>0.9*Time, 1 );

        resource_Q = (par.N - y_B(:,2)*par.q)./y_B(:,1);  % resource N:C ratio changes

        % recordeded information       
        U(i,1)= par.N;  
        U(i,2)= par.q;  
        U(i,3)= min(y_B(indx:end,1));  % resource biomass
        U(i,4)= min(y_B(indx:end,2));  % consumer biomass 
        U(i,5)= min(resource_Q(indx:end)); 
        U(i,6)= max(resource_Q(indx:end)); 
        U(i,7)= max(y_B(indx:end,2))-min(y_B(indx:end,2));  % stable or not

        i=i+1;
    end
end


U = sortrows(U, 1, 'descend');
U = sortrows(U, 2);
U(:,1) = log10(U(:,1));
consumer = reshape(U(:,4),[length(unique(U(:,1))) length(unique(U(:,2)))]);
% -1-->only resource； 0-->stable coexistence； 1-->not stable
coexistence = reshape(U(:,7),[length(unique(U(:,1))) length(unique(U(:,2)))]);
coexistence(coexistence>1e-13)=1;
coexistence(coexistence<1e-13)=0;
coexistence(consumer<1e-13)=-1;
for i = 30:size(coexistence,2)
    for j = 1: size(coexistence,2)
        if coexistence(i,j) == 1
            coexistence(i,j) = 0;
        end
    end
end

imagesc(coexistence);
colormap([144/255, 238/255, 144/255; 91/255 156/255 213/255;0.9, 0.9, 0.9; ]); 
h = colorbar;
set(h, 'Ticks', [], 'TickLabels', []);
y_ticks = unique(U(:,1));y_ticks = sort(y_ticks, 'descend');
x_ticks = unique(U(:,2));
set(gca, 'YDir', 'reverse');
set(gca, 'YTick', 1:20:length(y_ticks), 'YTickLabel', y_ticks(1:20:length(x_ticks))); 
set(gca, 'XTick', 1:20:length(x_ticks), 'XTickLabel', x_ticks(1:20:length(x_ticks))); 
set(gca, 'FontName', 'Arial', 'FontSize', 12, 'LineWidth', 1);
hold on;
plot(90,101-59, 'ok', 'MarkerFaceColor', 'k', 'MarkerSize', 6);
plot(90,101-83, 'ok', 'MarkerFaceColor', 'k', 'MarkerSize', 6); 
plot(12,101-59, 'ok', 'MarkerFaceColor', 'k', 'MarkerSize', 6); 
plot(12,101-83, 'ok', 'MarkerFaceColor', 'k', 'MarkerSize', 6);

